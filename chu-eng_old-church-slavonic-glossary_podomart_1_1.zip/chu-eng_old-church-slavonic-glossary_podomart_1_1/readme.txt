=========================================================
== Old Cyrillic font for Church Slavic and Old Russian ==
=========================================================

For use in GoldenDict:

In order to use the Old Cyrillic font "Monomakh" within articles, the search box and the wordlist on dictionaries with the language "Church Slavic", copy following attached files:

article-style.css
qt-style.css

into the GoldenDict folder:
Linux:		~/.goldendict
Windows:	%APPDATA%\GoldenDict

The Old Cyrillic font "Monomakh" will be retrieved from the internet, so there is no font installation necessary.

If you need the font also outside of GoldenDict, you need to work offline or in case of problems, install the font locally from https://sci.ponomar.net/fonts.html#fonts-for-academic-work (Monomakh Unicode font)



=== Issues
2021-09-24 ― qt-style.css seems not to work on every Linux installation (Ubuntu 18.04)